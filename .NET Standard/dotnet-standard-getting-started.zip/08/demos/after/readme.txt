The .csproj-files of the projects
- WiredBrainCoffee.Storage 
- WiredBrainCoffee.Simulators
have the NuGet settings like you saw them in the course module.

But the NuGet packages are not referenced as shown in the course module, because you first need to move the generated NuGet packages to a local folder on your machine like it is shown in the course module.

If you have any questions, please post them to the discussion tab on the course homepage on www.pluralsight.com

