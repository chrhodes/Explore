﻿namespace WiredBrainCoffee.Storage
{
  public class CoffeeMachineState
  {
    public int CounterCappuccino { get; set; }
  }
}
