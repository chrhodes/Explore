As we started with a brand new project in Visual Studio,
there's nothing in this "before" folder.