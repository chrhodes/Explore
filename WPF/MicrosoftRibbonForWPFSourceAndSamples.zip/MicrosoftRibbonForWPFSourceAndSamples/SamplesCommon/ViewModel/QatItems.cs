﻿using System.Collections.ObjectModel;

namespace RibbonWindowSample.ViewModel
{
    public class QatItemCollection : Collection<QatItem>
    {
    }
}
