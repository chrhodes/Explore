﻿namespace RibbonWindowSample.ViewModel
{
    /// <summary>
    /// DataModel for Tables Gallery
    /// </summary>
    public class RowColumnCount
    {
        public int RowCount {get;set;}
        public int ColumnCount {get;set;}
    }
}
