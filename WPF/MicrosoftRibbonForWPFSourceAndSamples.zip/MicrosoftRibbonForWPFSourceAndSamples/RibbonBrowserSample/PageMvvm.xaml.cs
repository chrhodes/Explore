﻿using System.Windows.Controls;

namespace RibbonBrowserSample
{
    /// <summary>
    /// Interaction logic for PageMvvm.xaml
    /// </summary>
    public partial class PageMvvm : Page
    {
        public PageMvvm()
        {
            InitializeComponent();
        }
    }
}
