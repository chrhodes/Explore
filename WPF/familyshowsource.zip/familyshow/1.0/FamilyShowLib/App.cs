using System;
using System.Collections.Generic;
using System.Text;

namespace Microsoft.FamilyShowLib
{
    /// <summary>
    /// Stores the properties spefic to this class library.
    /// </summary>
    public class App
    {
        // The name of the application folder.  This folder is used to save the 
        // files for this application such as the photos, stories and family data.
        public const string ApplicationFolderName = "Family.Show";
    }
}
