//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by w32clock.rc
//
#define IDC_MYICON                      2
#define IDD_W32CLOCK_DIALOG             102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDD_PROPPAGE_MEDIUM             106
#define IDI_W32CLOCK                    107
#define IDI_SMALL                       108
#define IDC_W32CLOCK                    109
#define IDR_MAINFRAME                   128
#define IDC_TAB1                        1000
#define IDC_BUTTON1                     1001
#define IDC_BUTTON2                     1002
#define IDC_BUTTON3                     1003
#define IDC_COMBO1                      1004
#define IDC_EDIT1                       1006
#define IDC_SPIN1                       1007
#define IDC_MONTHCALENDAR1              1008
#define IDC_MONTHCALENDAR2              1009
#define IDC_CUSTOM1                     1010
#define IDC_CLOCK                       1011
#define IDC_STATIC1                     1012
#define IDC_STATIC2                     1013
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1012
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
