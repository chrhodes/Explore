﻿Imports System.Text

Namespace HostingWpfUserControlInWf
	''' <summary>
	''' Interaction logic for UserControl1.xaml
	''' </summary>
	Partial Public Class UserControl1
		Inherits UserControl
		Public Sub New()
			InitializeComponent()
		End Sub
	End Class
End Namespace
