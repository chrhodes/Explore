Imports ClassLibrary1

'--
'-- Jeff Atwood
'-- http://www.codinghorror.com
'--
Public Class Form1
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtWhatUserCanDo As System.Windows.Forms.TextBox
    Friend WithEvents txtWhatHappened As System.Windows.Forms.TextBox
    Friend WithEvents txtHowUserAffected As System.Windows.Forms.TextBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents radioAbortRetryIgnore As System.Windows.Forms.RadioButton
    Friend WithEvents radioOK As System.Windows.Forms.RadioButton
    Friend WithEvents radioOKCancel As System.Windows.Forms.RadioButton
    Friend WithEvents radioRetryCancel As System.Windows.Forms.RadioButton
    Friend WithEvents radioYesNo As System.Windows.Forms.RadioButton
    Friend WithEvents radioYesNoCancel As System.Windows.Forms.RadioButton
    Friend WithEvents radioError As System.Windows.Forms.RadioButton
    Friend WithEvents radioExclamation As System.Windows.Forms.RadioButton
    Friend WithEvents radioQuestion As System.Windows.Forms.RadioButton
    Friend WithEvents radioInformation As System.Windows.Forms.RadioButton
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents radioButtonDefault As System.Windows.Forms.RadioButton
    Friend WithEvents radioButton3 As System.Windows.Forms.RadioButton
    Friend WithEvents radioButton2 As System.Windows.Forms.RadioButton
    Friend WithEvents radioButton1 As System.Windows.Forms.RadioButton
    Friend WithEvents checkEmailHandledException As System.Windows.Forms.CheckBox
    Friend WithEvents CheckBox1 As System.Windows.Forms.CheckBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents txtMoreInfo As System.Windows.Forms.TextBox
    Friend WithEvents txtSMTPPort As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents txtSMTPServer As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TabPage3 As System.Windows.Forms.TabPage
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtSMTPDomain As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtEmailTo As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents txtContactInfo As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(Form1))
        Me.TabControl1 = New System.Windows.Forms.TabControl
        Me.TabPage3 = New System.Windows.Forms.TabPage
        Me.Label10 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.txtSMTPDomain = New System.Windows.Forms.TextBox
        Me.Label8 = New System.Windows.Forms.Label
        Me.txtSMTPPort = New System.Windows.Forms.TextBox
        Me.Label6 = New System.Windows.Forms.Label
        Me.txtSMTPServer = New System.Windows.Forms.TextBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.TabPage1 = New System.Windows.Forms.TabPage
        Me.txtMoreInfo = New System.Windows.Forms.TextBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.CheckBox1 = New System.Windows.Forms.CheckBox
        Me.checkEmailHandledException = New System.Windows.Forms.CheckBox
        Me.GroupBox3 = New System.Windows.Forms.GroupBox
        Me.radioButtonDefault = New System.Windows.Forms.RadioButton
        Me.radioButton3 = New System.Windows.Forms.RadioButton
        Me.radioButton2 = New System.Windows.Forms.RadioButton
        Me.radioButton1 = New System.Windows.Forms.RadioButton
        Me.GroupBox2 = New System.Windows.Forms.GroupBox
        Me.radioInformation = New System.Windows.Forms.RadioButton
        Me.radioQuestion = New System.Windows.Forms.RadioButton
        Me.radioExclamation = New System.Windows.Forms.RadioButton
        Me.radioError = New System.Windows.Forms.RadioButton
        Me.GroupBox1 = New System.Windows.Forms.GroupBox
        Me.radioYesNoCancel = New System.Windows.Forms.RadioButton
        Me.radioYesNo = New System.Windows.Forms.RadioButton
        Me.radioRetryCancel = New System.Windows.Forms.RadioButton
        Me.radioOKCancel = New System.Windows.Forms.RadioButton
        Me.radioOK = New System.Windows.Forms.RadioButton
        Me.radioAbortRetryIgnore = New System.Windows.Forms.RadioButton
        Me.Button3 = New System.Windows.Forms.Button
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.txtWhatUserCanDo = New System.Windows.Forms.TextBox
        Me.txtWhatHappened = New System.Windows.Forms.TextBox
        Me.txtHowUserAffected = New System.Windows.Forms.TextBox
        Me.Button2 = New System.Windows.Forms.Button
        Me.TabPage2 = New System.Windows.Forms.TabPage
        Me.Button1 = New System.Windows.Forms.Button
        Me.Label11 = New System.Windows.Forms.Label
        Me.txtEmailTo = New System.Windows.Forms.TextBox
        Me.Label12 = New System.Windows.Forms.Label
        Me.txtContactInfo = New System.Windows.Forms.TextBox
        Me.PictureBox1 = New System.Windows.Forms.PictureBox
        Me.TabControl1.SuspendLayout()
        Me.TabPage3.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        Me.SuspendLayout()
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage3)
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.TabPage2)
        Me.TabControl1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TabControl1.Location = New System.Drawing.Point(0, 0)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(708, 501)
        Me.TabControl1.TabIndex = 0
        '
        'TabPage3
        '
        Me.TabPage3.Controls.Add(Me.PictureBox1)
        Me.TabPage3.Controls.Add(Me.txtContactInfo)
        Me.TabPage3.Controls.Add(Me.Label12)
        Me.TabPage3.Controls.Add(Me.txtEmailTo)
        Me.TabPage3.Controls.Add(Me.Label11)
        Me.TabPage3.Controls.Add(Me.Label10)
        Me.TabPage3.Controls.Add(Me.Label9)
        Me.TabPage3.Controls.Add(Me.txtSMTPDomain)
        Me.TabPage3.Controls.Add(Me.Label8)
        Me.TabPage3.Controls.Add(Me.txtSMTPPort)
        Me.TabPage3.Controls.Add(Me.Label6)
        Me.TabPage3.Controls.Add(Me.txtSMTPServer)
        Me.TabPage3.Controls.Add(Me.Label4)
        Me.TabPage3.Location = New System.Drawing.Point(4, 22)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Size = New System.Drawing.Size(700, 475)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "SMTP Settings"
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Label10.Location = New System.Drawing.Point(16, 128)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(284, 16)
        Me.Label10.TabIndex = 8
        Me.Label10.Text = "Don't forget to set the mailto: address in App.Config!"
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(12, 12)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(460, 16)
        Me.Label9.TabIndex = 7
        Me.Label9.Text = "Edit the default values in SimpleMail.vb to match your preferred outgoing mail se" & _
        "rver."
        '
        'txtSMTPDomain
        '
        Me.txtSMTPDomain.Enabled = False
        Me.txtSMTPDomain.Location = New System.Drawing.Point(256, 36)
        Me.txtSMTPDomain.Name = "txtSMTPDomain"
        Me.txtSMTPDomain.Size = New System.Drawing.Size(256, 20)
        Me.txtSMTPDomain.TabIndex = 6
        Me.txtSMTPDomain.Text = ""
        '
        'Label8
        '
        Me.Label8.Location = New System.Drawing.Point(12, 36)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(144, 16)
        Me.Label8.TabIndex = 5
        Me.Label8.Text = "SimpleMail.DefaultDomain"
        '
        'txtSMTPPort
        '
        Me.txtSMTPPort.Enabled = False
        Me.txtSMTPPort.Location = New System.Drawing.Point(256, 88)
        Me.txtSMTPPort.MaxLength = 4
        Me.txtSMTPPort.Name = "txtSMTPPort"
        Me.txtSMTPPort.Size = New System.Drawing.Size(56, 20)
        Me.txtSMTPPort.TabIndex = 3
        Me.txtSMTPPort.Text = ""
        '
        'Label6
        '
        Me.Label6.Location = New System.Drawing.Point(12, 92)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(88, 16)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "SimpleMail.Port"
        '
        'txtSMTPServer
        '
        Me.txtSMTPServer.Enabled = False
        Me.txtSMTPServer.Location = New System.Drawing.Point(256, 60)
        Me.txtSMTPServer.Name = "txtSMTPServer"
        Me.txtSMTPServer.Size = New System.Drawing.Size(256, 20)
        Me.txtSMTPServer.TabIndex = 1
        Me.txtSMTPServer.Text = ""
        '
        'Label4
        '
        Me.Label4.Location = New System.Drawing.Point(12, 64)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 16)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "SimpleMail.Server"
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.txtMoreInfo)
        Me.TabPage1.Controls.Add(Me.Label5)
        Me.TabPage1.Controls.Add(Me.CheckBox1)
        Me.TabPage1.Controls.Add(Me.checkEmailHandledException)
        Me.TabPage1.Controls.Add(Me.GroupBox3)
        Me.TabPage1.Controls.Add(Me.GroupBox2)
        Me.TabPage1.Controls.Add(Me.GroupBox1)
        Me.TabPage1.Controls.Add(Me.Button3)
        Me.TabPage1.Controls.Add(Me.Label3)
        Me.TabPage1.Controls.Add(Me.Label2)
        Me.TabPage1.Controls.Add(Me.Label1)
        Me.TabPage1.Controls.Add(Me.txtWhatUserCanDo)
        Me.TabPage1.Controls.Add(Me.txtWhatHappened)
        Me.TabPage1.Controls.Add(Me.txtHowUserAffected)
        Me.TabPage1.Controls.Add(Me.Button2)
        Me.TabPage1.Location = New System.Drawing.Point(4, 22)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Size = New System.Drawing.Size(700, 475)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "Handled Exception"
        '
        'txtMoreInfo
        '
        Me.txtMoreInfo.Enabled = False
        Me.txtMoreInfo.Location = New System.Drawing.Point(32, 304)
        Me.txtMoreInfo.Multiline = True
        Me.txtMoreInfo.Name = "txtMoreInfo"
        Me.txtMoreInfo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtMoreInfo.Size = New System.Drawing.Size(512, 60)
        Me.txtMoreInfo.TabIndex = 7
        Me.txtMoreInfo.Text = ""
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(8, 288)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(104, 16)
        Me.Label5.TabIndex = 6
        Me.Label5.Text = "More information:"
        '
        'CheckBox1
        '
        Me.CheckBox1.Checked = True
        Me.CheckBox1.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox1.Location = New System.Drawing.Point(32, 372)
        Me.CheckBox1.Name = "CheckBox1"
        Me.CheckBox1.Size = New System.Drawing.Size(312, 20)
        Me.CheckBox1.TabIndex = 8
        Me.CheckBox1.Text = "Use the actual exception for the ""more information"" text"
        '
        'checkEmailHandledException
        '
        Me.checkEmailHandledException.Checked = True
        Me.checkEmailHandledException.CheckState = System.Windows.Forms.CheckState.Checked
        Me.checkEmailHandledException.Location = New System.Drawing.Point(16, 420)
        Me.checkEmailHandledException.Name = "checkEmailHandledException"
        Me.checkEmailHandledException.Size = New System.Drawing.Size(288, 16)
        Me.checkEmailHandledException.TabIndex = 12
        Me.checkEmailHandledException.Text = "Send an email notification for this handled exception"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.radioButtonDefault)
        Me.GroupBox3.Controls.Add(Me.radioButton3)
        Me.GroupBox3.Controls.Add(Me.radioButton2)
        Me.GroupBox3.Controls.Add(Me.radioButton1)
        Me.GroupBox3.Location = New System.Drawing.Point(556, 324)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(132, 104)
        Me.GroupBox3.TabIndex = 11
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Default Button"
        '
        'radioButtonDefault
        '
        Me.radioButtonDefault.Checked = True
        Me.radioButtonDefault.Location = New System.Drawing.Point(12, 80)
        Me.radioButtonDefault.Name = "radioButtonDefault"
        Me.radioButtonDefault.Size = New System.Drawing.Size(60, 16)
        Me.radioButtonDefault.TabIndex = 3
        Me.radioButtonDefault.TabStop = True
        Me.radioButtonDefault.Text = "Default"
        '
        'radioButton3
        '
        Me.radioButton3.Location = New System.Drawing.Point(12, 60)
        Me.radioButton3.Name = "radioButton3"
        Me.radioButton3.Size = New System.Drawing.Size(64, 16)
        Me.radioButton3.TabIndex = 2
        Me.radioButton3.Text = "Button3"
        '
        'radioButton2
        '
        Me.radioButton2.Location = New System.Drawing.Point(12, 40)
        Me.radioButton2.Name = "radioButton2"
        Me.radioButton2.Size = New System.Drawing.Size(64, 16)
        Me.radioButton2.TabIndex = 1
        Me.radioButton2.Text = "Button2"
        '
        'radioButton1
        '
        Me.radioButton1.Location = New System.Drawing.Point(12, 20)
        Me.radioButton1.Name = "radioButton1"
        Me.radioButton1.Size = New System.Drawing.Size(64, 16)
        Me.radioButton1.TabIndex = 0
        Me.radioButton1.Text = "Button1"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.radioInformation)
        Me.GroupBox2.Controls.Add(Me.radioQuestion)
        Me.GroupBox2.Controls.Add(Me.radioExclamation)
        Me.GroupBox2.Controls.Add(Me.radioError)
        Me.GroupBox2.Location = New System.Drawing.Point(556, 192)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(132, 124)
        Me.GroupBox2.TabIndex = 10
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Icon"
        '
        'radioInformation
        '
        Me.radioInformation.Location = New System.Drawing.Point(12, 96)
        Me.radioInformation.Name = "radioInformation"
        Me.radioInformation.Size = New System.Drawing.Size(84, 20)
        Me.radioInformation.TabIndex = 3
        Me.radioInformation.Text = "Information"
        '
        'radioQuestion
        '
        Me.radioQuestion.Location = New System.Drawing.Point(12, 72)
        Me.radioQuestion.Name = "radioQuestion"
        Me.radioQuestion.Size = New System.Drawing.Size(72, 20)
        Me.radioQuestion.TabIndex = 2
        Me.radioQuestion.Text = "Question"
        '
        'radioExclamation
        '
        Me.radioExclamation.Location = New System.Drawing.Point(12, 48)
        Me.radioExclamation.Name = "radioExclamation"
        Me.radioExclamation.Size = New System.Drawing.Size(88, 20)
        Me.radioExclamation.TabIndex = 1
        Me.radioExclamation.Text = "Exclamation"
        '
        'radioError
        '
        Me.radioError.Checked = True
        Me.radioError.Location = New System.Drawing.Point(12, 24)
        Me.radioError.Name = "radioError"
        Me.radioError.Size = New System.Drawing.Size(48, 20)
        Me.radioError.TabIndex = 0
        Me.radioError.TabStop = True
        Me.radioError.Text = "Error"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.radioYesNoCancel)
        Me.GroupBox1.Controls.Add(Me.radioYesNo)
        Me.GroupBox1.Controls.Add(Me.radioRetryCancel)
        Me.GroupBox1.Controls.Add(Me.radioOKCancel)
        Me.GroupBox1.Controls.Add(Me.radioOK)
        Me.GroupBox1.Controls.Add(Me.radioAbortRetryIgnore)
        Me.GroupBox1.Location = New System.Drawing.Point(556, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(132, 172)
        Me.GroupBox1.TabIndex = 9
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Buttons"
        '
        'radioYesNoCancel
        '
        Me.radioYesNoCancel.Location = New System.Drawing.Point(12, 140)
        Me.radioYesNoCancel.Name = "radioYesNoCancel"
        Me.radioYesNoCancel.Size = New System.Drawing.Size(96, 20)
        Me.radioYesNoCancel.TabIndex = 5
        Me.radioYesNoCancel.Text = "YesNoCancel"
        '
        'radioYesNo
        '
        Me.radioYesNo.Location = New System.Drawing.Point(12, 116)
        Me.radioYesNo.Name = "radioYesNo"
        Me.radioYesNo.Size = New System.Drawing.Size(60, 20)
        Me.radioYesNo.TabIndex = 4
        Me.radioYesNo.Text = "YesNo"
        '
        'radioRetryCancel
        '
        Me.radioRetryCancel.Location = New System.Drawing.Point(12, 92)
        Me.radioRetryCancel.Name = "radioRetryCancel"
        Me.radioRetryCancel.Size = New System.Drawing.Size(96, 20)
        Me.radioRetryCancel.TabIndex = 3
        Me.radioRetryCancel.Text = "RetryCancel"
        '
        'radioOKCancel
        '
        Me.radioOKCancel.Location = New System.Drawing.Point(12, 68)
        Me.radioOKCancel.Name = "radioOKCancel"
        Me.radioOKCancel.Size = New System.Drawing.Size(76, 20)
        Me.radioOKCancel.TabIndex = 2
        Me.radioOKCancel.Text = "OKCancel"
        '
        'radioOK
        '
        Me.radioOK.Checked = True
        Me.radioOK.Location = New System.Drawing.Point(12, 44)
        Me.radioOK.Name = "radioOK"
        Me.radioOK.Size = New System.Drawing.Size(44, 20)
        Me.radioOK.TabIndex = 1
        Me.radioOK.TabStop = True
        Me.radioOK.Text = "OK"
        '
        'radioAbortRetryIgnore
        '
        Me.radioAbortRetryIgnore.Location = New System.Drawing.Point(12, 20)
        Me.radioAbortRetryIgnore.Name = "radioAbortRetryIgnore"
        Me.radioAbortRetryIgnore.Size = New System.Drawing.Size(112, 20)
        Me.radioAbortRetryIgnore.TabIndex = 0
        Me.radioAbortRetryIgnore.Text = "AbortRetryIgnore"
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(508, 436)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(180, 28)
        Me.Button3.TabIndex = 14
        Me.Button3.Text = "Handled Exception (defaults)"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(12, 196)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(128, 16)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "What the user can do:"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(8, 104)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(164, 16)
        Me.Label2.TabIndex = 2
        Me.Label2.Text = "How the user will be affected:"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(112, 16)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "What Happened:"
        '
        'txtWhatUserCanDo
        '
        Me.txtWhatUserCanDo.Location = New System.Drawing.Point(32, 220)
        Me.txtWhatUserCanDo.Multiline = True
        Me.txtWhatUserCanDo.Name = "txtWhatUserCanDo"
        Me.txtWhatUserCanDo.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtWhatUserCanDo.Size = New System.Drawing.Size(512, 60)
        Me.txtWhatUserCanDo.TabIndex = 5
        Me.txtWhatUserCanDo.Text = "List anything the user can do to resolve this problem or condition, including con" & _
        "tacting (contact) or perhaps visiting http://www.codinghorror.com"
        '
        'txtWhatHappened
        '
        Me.txtWhatHappened.Location = New System.Drawing.Point(32, 36)
        Me.txtWhatHappened.Multiline = True
        Me.txtWhatHappened.Name = "txtWhatHappened"
        Me.txtWhatHappened.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtWhatHappened.Size = New System.Drawing.Size(508, 60)
        Me.txtWhatHappened.TabIndex = 1
        Me.txtWhatHappened.Text = "Describe what happened to (app) in plain, non technical terms"
        '
        'txtHowUserAffected
        '
        Me.txtHowUserAffected.Location = New System.Drawing.Point(32, 128)
        Me.txtHowUserAffected.Multiline = True
        Me.txtHowUserAffected.Name = "txtHowUserAffected"
        Me.txtHowUserAffected.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.txtHowUserAffected.Size = New System.Drawing.Size(508, 60)
        Me.txtHowUserAffected.TabIndex = 3
        Me.txtHowUserAffected.Text = "Describe how the user will be affected by this problem or condition; be specific." & _
        ""
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(320, 436)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(180, 28)
        Me.Button2.TabIndex = 13
        Me.Button2.Text = "Handled Exception (customized)"
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.Button1)
        Me.TabPage2.Location = New System.Drawing.Point(4, 22)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Size = New System.Drawing.Size(700, 475)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "Unhandled Exception"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(262, 223)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(176, 28)
        Me.Button1.TabIndex = 1
        Me.Button1.Text = "Generate Unhandled Exception"
        '
        'Label11
        '
        Me.Label11.Location = New System.Drawing.Point(12, 328)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(200, 16)
        Me.Label11.TabIndex = 9
        Me.Label11.Text = "UnhandledExceptionManager/EmailTo"
        '
        'txtEmailTo
        '
        Me.txtEmailTo.Enabled = False
        Me.txtEmailTo.Location = New System.Drawing.Point(256, 324)
        Me.txtEmailTo.Name = "txtEmailTo"
        Me.txtEmailTo.Size = New System.Drawing.Size(280, 20)
        Me.txtEmailTo.TabIndex = 10
        Me.txtEmailTo.Text = ""
        '
        'Label12
        '
        Me.Label12.Location = New System.Drawing.Point(12, 352)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(216, 16)
        Me.Label12.TabIndex = 11
        Me.Label12.Text = "UnhandledExceptionManager/ContactInfo"
        '
        'txtContactInfo
        '
        Me.txtContactInfo.Enabled = False
        Me.txtContactInfo.Location = New System.Drawing.Point(256, 348)
        Me.txtContactInfo.Name = "txtContactInfo"
        Me.txtContactInfo.Size = New System.Drawing.Size(280, 20)
        Me.txtContactInfo.TabIndex = 12
        Me.txtContactInfo.Text = ""
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(16, 152)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(673, 163)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.PictureBox1.TabIndex = 13
        Me.PictureBox1.TabStop = False
        '
        'Form1
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.ClientSize = New System.Drawing.Size(708, 501)
        Me.Controls.Add(Me.TabControl1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage3.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub GenerateException()
        '-- just a simple "object not initialized" exception (should read "as new")
        Dim x As Specialized.NameValueCollection
        MessageBox.Show(x.Count.ToString)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        GenerateException()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            GenerateException()
        Catch ex As Exception
            HandledExceptionManager.EmailError = checkEmailHandledException.Checked
            If CheckBox1.Checked Then
                '-- use exception as "more"
                HandledExceptionManager.ShowDialog(txtWhatHappened.Text, _
                    txtHowUserAffected.Text, _
                    txtWhatUserCanDo.Text, _
                    ex, _
                    GetButtonType, _
                    GetIconType, _
                    GetDefaultButton)
            Else
                '-- use custom text as "more"
                HandledExceptionManager.ShowDialog(txtWhatHappened.Text, _
                    txtHowUserAffected.Text, _
                    txtWhatUserCanDo.Text, _
                    txtMoreInfo.Text, _
                    GetButtonType, _
                    GetIconType, _
                    GetDefaultButton)
            End If
        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Try
            GenerateException()
        Catch ex As Exception
            HandledExceptionManager.EmailError = checkEmailHandledException.Checked
            '-- minimal form, no extra params
            HandledExceptionManager.ShowDialog(txtWhatHappened.Text, _
                txtHowUserAffected.Text, _
                txtWhatUserCanDo.Text, _
                ex)
        End Try
    End Sub


    Private Function GetDefaultButton() As HandledExceptionManager.UserErrorDefaultButton
        If radioButton1.Checked Then
            Return HandledExceptionManager.UserErrorDefaultButton.Button1
        End If
        If radioButton2.Checked Then
            Return HandledExceptionManager.UserErrorDefaultButton.Button2
        End If
        If radioButton3.Checked Then
            Return HandledExceptionManager.UserErrorDefaultButton.Button3
        End If
        Return HandledExceptionManager.UserErrorDefaultButton.Default
    End Function

    Private Function GetIconType() As MessageBoxIcon
        If radioExclamation.Checked Then
            Return MessageBoxIcon.Exclamation
        End If
        If radioQuestion.Checked Then
            Return MessageBoxIcon.Question
        End If
        If radioInformation.Checked Then
            Return MessageBoxIcon.Information
        End If
        Return MessageBoxIcon.Error
    End Function

    Private Function GetButtonType() As MessageBoxButtons
        If radioAbortRetryIgnore.Checked Then
            Return MessageBoxButtons.AbortRetryIgnore
        End If
        If radioOKCancel.Checked Then
            Return MessageBoxButtons.OKCancel
        End If
        If radioRetryCancel.Checked Then
            Return MessageBoxButtons.RetryCancel
        End If
        If radioYesNo.Checked Then
            Return MessageBoxButtons.YesNo
        End If
        If radioYesNoCancel.Checked Then
            Return MessageBoxButtons.YesNoCancel
        End If
        Return MessageBoxButtons.OK
    End Function


    Private Sub CheckBox1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CheckBox1.CheckedChanged
        If CheckBox1.Checked = True Then
            If txtMoreInfo.Text <> "" Then
                txtMoreInfo.Tag = txtMoreInfo.Text
                txtMoreInfo.Text = ""
            End If
        Else
            If txtMoreInfo.Text = "" Then
                If Not txtMoreInfo.Tag Is Nothing Then
                    txtMoreInfo.Text = txtMoreInfo.Tag.ToString
                End If
            End If
        End If
        txtMoreInfo.Enabled = Not CheckBox1.Checked
    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim smtp As New SimpleMail.SMTPClient

        txtSMTPDomain.Text = smtp.DefaultDomain
        txtSMTPPort.Text = smtp.Port.ToString
        txtSMTPServer.Text = smtp.Server.ToString
        txtEmailTo.Text = AppSettings.GetString("UnhandledExceptionManager/EmailTo")
        txtContactInfo.Text = AppSettings.GetString("UnhandledExceptionManager/ContactInfo")
    End Sub
End Class
