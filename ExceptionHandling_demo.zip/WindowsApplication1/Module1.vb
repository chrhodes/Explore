Imports ClassLibrary1

'--
'-- Jeff Atwood
'-- http://www.codinghorror.com
'--
Module Module1

    Public Sub Main()
        UnhandledExceptionManager.AddHandler()
        Dim frm As New Form1
        Application.Run(frm)
    End Sub

End Module
