Imports ClassLibrary1

'--
'-- Jeff Atwood
'-- http://www.codinghorror.com
'--
Module Module1

    Sub Main()
        UnhandledExceptionManager.AddHandler(True)
        Console.WriteLine("Hello World!")
        GenerateException()
        Console.WriteLine("End of Sub Main(). Press ENTER to continue...")
        Console.ReadLine()
    End Sub

    Sub GenerateException()
        '-- just a simple "object not initialized" exception (should read "as new")
        Dim x As Specialized.NameValueCollection
        Console.WriteLine(x.Count)
    End Sub

End Module
